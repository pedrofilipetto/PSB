#ifndef UI_H
#define UI_H

#include <stdbool.h>
#include "board.h"

void ui_print_board(const Board *b, bool reveal_all); // imprime + números/bandeiras
void ui_prompt(void);                                 // mostra prompt "comando> "
bool ui_parse_command(char *line, char *op, int *r, int *c); // op: 'r','f','q'

#endif
