#ifndef BOARD_H
#define BOARD_H

#define ROWS 5
#define COLS 5
#define MINES 3

void limpar_tabuleiros(void);
void colocar_bombas(void);
void contar_adjacentes(void);
void imprimir_tabuleiro(int revelar_tudo);
int  revelar_celula(int r, int c, int *explodiu);
void alternar_bandeira(int r, int c);
int  escondidas_sem_bomba(void);

#endif
