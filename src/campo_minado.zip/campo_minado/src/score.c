#include <stdio.h>
#include <string.h>
#include "score.h"

typedef struct {
    double valor;
    char nome[64];
} Score;

static Score scores[MAX_SCORES];
static int count = 0;

void carregar_scores(void) {
    count = 0;
    FILE *f = fopen(SCORE_FILE, "r");
    if (!f) return;

    while (count < MAX_SCORES &&
           fscanf(f, " %lf;%63[^\n]\n", &scores[count].valor, scores[count].nome) == 2) {
        count++;
    }
    fclose(f);
}

void inserir_score(const char *nome, double valor) {
    if (count < MAX_SCORES) {
        scores[count].valor = valor;
        strncpy(scores[count].nome, nome, 63);
        scores[count].nome[63] = '\0';
        count++;
    } else {
        if (valor > scores[count-1].valor)
            scores[count-1].valor = valor;
    }

    /* ordenação decrescente simples */
    for (int i = 0; i < count; i++)
        for (int j = 0; j + 1 < count; j++)
            if (scores[j].valor < scores[j+1].valor) {
                Score tmp = scores[j];
                scores[j] = scores[j+1];
                scores[j+1] = tmp;
            }

    if (count > MAX_SCORES) count = MAX_SCORES;
}

void salvar_scores(void) {
    FILE *f = fopen(SCORE_FILE, "w");
    if (!f) return;
    for (int i = 0; i < count; i++)
        fprintf(f, "%.2f;%s\n", scores[i].valor, scores[i].nome);
    fclose(f);
}

void mostrar_scores(void) {
    if (count == 0) {
        printf("(sem pontuações ainda)\n");
        return;
    }
    printf("\n===== RANKING =====\n");
    for (int i = 0; i < count; i++)
        printf("%2d) %-15s %.2f\n", i+1, scores[i].nome, scores[i].valor);
}
