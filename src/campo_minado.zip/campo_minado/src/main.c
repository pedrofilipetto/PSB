#include "game.h"

int main(void) {
    jogar_campo_minado();
    return 0;
}
