#ifndef GAME_H
#define GAME_H

void jogar_campo_minado(void);

#endif
