#include <stdio.h>
#include <string.h>
#include "board.h"
#include "score.h"

static double calcular_score(int reveladas) {
    int total = ROWS * COLS - MINES;
    return 100.0 * reveladas / total;
}

void jogar_campo_minado(void) {
    char nome[64];
    printf("==== CAMPO MINADO ====\n");
    printf("Digite seu nome: ");
    fgets(nome, sizeof(nome), stdin);
    nome[strcspn(nome, "\n")] = '\0';

    limpar_tabuleiros();
    colocar_bombas();
    contar_adjacentes();

    int explodiu = 0, reveladas = 0;
    char comando;
    int r, c;

    while (!explodiu) {
        imprimir_tabuleiro(0);
        printf("Comando (r i j / f i j / q): ");
        if (scanf(" %c", &comando) != 1) break;
        if (comando == 'q') break;

        if (comando == 'r' && scanf("%d %d", &r, &c) == 2) {
            int novos = revelar_celula(r, c, &explodiu);
            reveladas += novos;
            if (explodiu) {
                printf("\n💥 Bomba! Fim de jogo.\n");
                imprimir_tabuleiro(1);
                break;
            }
            if (escondidas_sem_bomba() == 0) {
                printf("\n🎉 Parabéns, você venceu!\n");
                imprimir_tabuleiro(1);
                double score = calcular_score(reveladas);
                printf("Seu escore: %.2f\n", score);

                carregar_scores();
                inserir_score(nome, score);
                salvar_scores();
                mostrar_scores();
                break;
            }
        } else if (comando == 'f' && scanf("%d %d", &r, &c) == 2) {
            alternar_bandeira(r, c);
        }
    }
}
