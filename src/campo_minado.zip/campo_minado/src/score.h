#ifndef SCORE_H
#define SCORE_H

#define MAX_SCORES 10
#define SCORE_FILE "scores.txt"

void carregar_scores(void);
void inserir_score(const char *nome, double valor);
void salvar_scores(void);
void mostrar_scores(void);

#endif
