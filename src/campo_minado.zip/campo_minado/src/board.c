#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "board.h"

static int board[ROWS][COLS];
static int revealed[ROWS][COLS];
static int flagged[ROWS][COLS];

static int in_bounds(int r, int c) {
    return r >= 0 && r < ROWS && c >= 0 && c < COLS;
}

void limpar_tabuleiros(void) {
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++) {
            board[r][c] = 0;
            revealed[r][c] = 0;
            flagged[r][c] = 0;
        }
}

void colocar_bombas(void) {
    int colocadas = 0;
    srand((unsigned)time(NULL));
    while (colocadas < MINES) {
        int r = rand() % ROWS;
        int c = rand() % COLS;
        if (board[r][c] != -1) {
            board[r][c] = -1;
            colocadas++;
        }
    }
}

void contar_adjacentes(void) {
    int dr[8] = {-1,-1,-1, 0, 0, 1, 1, 1};
    int dc[8] = {-1, 0, 1,-1, 1,-1, 0, 1};

    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < COLS; c++) {
            if (board[r][c] == -1) continue;
            int soma = 0;
            for (int k = 0; k < 8; k++) {
                int nr = r + dr[k];
                int nc = c + dc[k];
                if (in_bounds(nr, nc) && board[nr][nc] == -1)
                    soma++;
            }
            board[r][c] = soma;
        }
    }
}

void imprimir_tabuleiro(int revelar_tudo) {
    printf("    ");
    for (int c = 0; c < COLS; c++) printf("%2d ", c);
    printf("\n");

    for (int r = 0; r < ROWS; r++) {
        printf("%2d |", r);
        for (int c = 0; c < COLS; c++) {
            char ch = 'X';
            if (revelar_tudo || revealed[r][c]) {
                if (board[r][c] == -1) ch = '*';
                else if (board[r][c] == 0) ch = ' ';
                else ch = (char)('0' + board[r][c]);
            } else if (flagged[r][c]) {
                ch = '+';
            }
            printf(" %c ", ch);
        }
        printf("|\n");
    }
}

/* Flood recursivo */
int revelar_celula(int r, int c, int *explodiu) {
    if (!in_bounds(r, c)) return 0;
    if (revealed[r][c] || flagged[r][c]) return 0;

    revealed[r][c] = 1;
    if (board[r][c] == -1) { *explodiu = 1; return 1; }

    int novos = 1;
    if (board[r][c] == 0) {
        int dr[8] = {-1,-1,-1, 0, 0, 1, 1, 1};
        int dc[8] = {-1, 0, 1,-1, 1,-1, 0, 1};
        for (int k = 0; k < 8; k++)
            novos += revelar_celula(r+dr[k], c+dc[k], explodiu);
    }
    return novos;
}

void alternar_bandeira(int r, int c) {
    if (in_bounds(r, c) && !revealed[r][c])
        flagged[r][c] = !flagged[r][c];
}

int escondidas_sem_bomba(void) {
    int total_sem_bomba = ROWS * COLS - MINES;
    int reveladas = 0;
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            if (revealed[r][c] && board[r][c] != -1)
                reveladas++;
    return total_sem_bomba - reveladas;
}
